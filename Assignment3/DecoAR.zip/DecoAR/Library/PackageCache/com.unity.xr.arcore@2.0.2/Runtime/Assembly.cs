using UnityEngine.Scripting;

[assembly: AlwaysLinkAssembly]
